# HWT Gün Adı Düzenleyici — GT 6 / GT 6 Pro

Bu güncelleme, daha önce gönderilen `GlassTexture.hwt` dosyasının gerçek yapısına göre hazırlandı.

## Neler değişti?
- HWT dış ZIP paketini açar.
- `com.huawei.watchface` içindeki ikinci ZIP paketini de açar.
- `watchface/res/A100_089.png`–`A100_095.png` gün adı görsellerini bulur (GlassTexture kadranında Monday–Sunday).
- Kullanıcının girdiği Türkçe gün adlarıyla 120×23 PNG etiketleri yeniden üretir.
- İç paketi tekrar oluşturur ve yeni bir `_tr.hwt` dosyası olarak kaydeder; orijinal dosyaya dokunmaz.

Varsayılan Türkçe adlar: Pazartesi, Salı, Çarşamba, Perşembe, Cuma, Cumartesi, Pazar.

## APK derleme
- Android Studio ile bu klasörü açıp **Build > Build APK(s)** seçin; veya
- Android SDK ve JDK 17 kurulu bir ortamda `./gradlew assembleDebug` çalıştırın.
- APK yolu: `app/build/outputs/apk/debug/app-debug.apk`

## Önemli uyumluluk notu
Görsel adları kadrandan kadrana değişebilir. Bu sürüm, özellikle incelenen **GlassTexture.hwt** içindeki bilinen A100_089–A100_095 gün etiketi eşlemesini destekler. Başka HWT dosyalarında farklı kaynak isimleri veya farklı iç paket formatı varsa uygulama bunu otomatik tahmin etmez ve kaydetmeyi durdurur.

Bu sürüm gün adı görsellerini değiştirir; sayısal tarih ve ay/gün sıralama biçimini değiştirmez. PNG metni orijinal görselin yaklaşık rengi ve boyutuyla yeniden çizildiği için yazı tipi birebir aynı olmayabilir. Saate yüklemeden önce yeni HWT dosyasını kontrol edin.
