# APK oluşturma (Türkçe)
1. ZIP'i çıkar.
2. Android Studio'da `HWT_Maker_GT6` klasörünü aç veya JDK 17 kurulu terminal kullan.
3. Android SDK Platform 35 ve Build Tools kurulu olmalı.
4. Terminalde `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`) çalıştır.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

Bu ortamda Android SDK bulunmadığı için APK burada derlenmedi; kaynak proje derlemeye hazırlandı.
