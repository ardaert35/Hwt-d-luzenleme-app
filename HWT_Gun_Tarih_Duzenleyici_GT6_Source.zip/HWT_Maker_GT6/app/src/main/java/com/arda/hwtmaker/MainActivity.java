package com.arda.hwtmaker;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
  static final int PICK_HWT=10, SAVE_HWT=12;
  static final String FACE_ENTRY="com.huawei.watchface";
  // The supplied GlassTexture HWT stores weekday labels as individual 120x23 PNGs.
  static final String[] DAY_FILES={"watchface/res/A100_089.png","watchface/res/A100_090.png","watchface/res/A100_091.png","watchface/res/A100_092.png","watchface/res/A100_093.png","watchface/res/A100_094.png","watchface/res/A100_095.png"};
  static final String[] ENGLISH={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
  static final String[] TURKISH={"Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"};
  LinearLayout root, dayFields; TextView status, selectedInfo; EditText[] dayEditors=new EditText[7];
  Uri hwtUri; String hwtName="watchface.hwt"; boolean loaded=false, nestedFound=false;
  final LinkedHashMap<String,byte[]> files=new LinkedHashMap<>();
  final LinkedHashMap<String,byte[]> nestedFiles=new LinkedHashMap<>();
  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();}
  TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(4),dp(7),dp(4),dp(7));return t;}
  Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
  void buildUi(){
    ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(14),dp(16),dp(20));root.setBackgroundColor(Color.rgb(15,17,23));sc.addView(root);
    TextView title=label("HWT Gün Adı Düzenleyici",24);title.setTypeface(null,Typeface.BOLD);root.addView(title);
    TextView sub=label("Huawei Watch GT 6 / GT 6 Pro • PNG gün etiketlerini düzenler",13);sub.setTextColor(Color.LTGRAY);root.addView(sub);
    Button open=button("1 • HWT dosyası seç");open.setOnClickListener(v->pickHwt());root.addView(open);
    selectedInfo=label("Henüz HWT seçilmedi",13);selectedInfo.setTextColor(Color.rgb(160,200,255));root.addView(selectedInfo);
    TextView explanation=label("GlassTexture kadranında gün adları PNG görselleri olarak saklanır. Aşağıdaki alanları değiştir; görseller yeniden oluşturulur ve iç paket tekrar HWT içine yerleştirilir.",13);explanation.setTextColor(Color.LTGRAY);root.addView(explanation);
    dayFields=new LinearLayout(this);dayFields.setOrientation(1);root.addView(dayFields);
    for(int i=0;i<7;i++){TextView l=label(ENGLISH[i]+" →",14);dayFields.addView(l);EditText e=new EditText(this);e.setSingleLine(true);e.setText(TURKISH[i]);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.GRAY));dayFields.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));dayEditors[i]=e;}
    Button reset=button("Türkçe gün adlarını doldur");reset.setOnClickListener(v->{for(int i=0;i<7;i++)dayEditors[i].setText(TURKISH[i]);});root.addView(reset);
    Button save=button("2 • Yeni HWT dosyası olarak kaydet");save.setOnClickListener(v->exportHwt());root.addView(save);
    status=label("Orijinal dosya korunur. Kaydetmeden önce HWT seç.",12);status.setTextColor(Color.LTGRAY);root.addView(status);setContentView(sc);
  }
  void pickHwt(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_HWT);}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;try{if(req==PICK_HWT){hwtUri=data.getData();hwtName=getName(hwtUri);loadArchive();}else if(req==SAVE_HWT)writeArchive(data.getData());}catch(Exception e){setStatus("Hata: "+e.getMessage());}}
  void loadArchive() throws Exception {
    files.clear();nestedFiles.clear();loaded=false;nestedFound=false;
    try(InputStream raw=getContentResolver().openInputStream(hwtUri);ZipInputStream zin=new ZipInputStream(new BufferedInputStream(raw))){ZipEntry e;while((e=zin.getNextEntry())!=null){if(!e.isDirectory())files.put(e.getName(),readAll(zin));}}
    if(files.isEmpty())throw new IOException("HWT ZIP arşivi olarak açılamadı.");
    byte[] face=files.get(FACE_ENTRY);
    if(face==null)throw new IOException("com.huawei.watchface dosyası bulunamadı.");
    try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(face))){ZipEntry e;while((e=zin.getNextEntry())!=null){if(!e.isDirectory())nestedFiles.put(e.getName(),readAll(zin));}}
    if(nestedFiles.isEmpty())throw new IOException("Kadranın iç paketi ZIP olarak okunamadı.");
    int found=0;for(String n:DAY_FILES)if(nestedFiles.containsKey(n))found++;
    nestedFound=found==7;loaded=true;
    selectedInfo.setText(hwtName+" • "+files.size()+" dış dosya • "+found+"/7 gün görseli bulundu");
    if(nestedFound)setStatus("Gün görselleri bulundu. Adları düzenleyip yeni HWT olarak kaydedebilirsin.");
    else setStatus("Bu kadranın görsel adları beklenen dosya adlarıyla eşleşmedi. Kaydetmek orijinal dosyayı değiştirmez.");
  }
  void exportHwt(){if(!loaded){toast("Önce desteklenen bir HWT dosyası seç.");return;}if(!nestedFound){toast("Bu kadrandaki 7 gün PNG'si bulunamadı; dosyayı değiştirmeden bırakıyorum.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");String base=hwtName.toLowerCase(Locale.ROOT).endsWith(".hwt")?hwtName.substring(0,hwtName.length()-4):hwtName;i.putExtra(Intent.EXTRA_TITLE,base+"_tr.hwt");startActivityForResult(i,SAVE_HWT);}
  void writeArchive(Uri out){try{
    LinkedHashMap<String,byte[]> rebuilt=new LinkedHashMap<>(nestedFiles);
    for(int i=0;i<7;i++){String text=dayEditors[i].getText().toString().trim();if(text.isEmpty())throw new IOException(ENGLISH[i]+" alanı boş olamaz.");byte[] old=rebuilt.get(DAY_FILES[i]);Bitmap reference=BitmapFactory.decodeByteArray(old,0,old.length);int w=reference==null?120:reference.getWidth(),h=reference==null?23:reference.getHeight();int color=sampleTextColor(reference);if(reference!=null)reference.recycle();rebuilt.put(DAY_FILES[i],renderLabel(text,w,h,color));}
    ByteArrayOutputStream nestedOut=new ByteArrayOutputStream();try(ZipOutputStream zout=new ZipOutputStream(nestedOut)){for(Map.Entry<String,byte[]> e:rebuilt.entrySet()){ZipEntry ze=new ZipEntry(e.getKey());zout.putNextEntry(ze);zout.write(e.getValue());zout.closeEntry();}}
    files.put(FACE_ENTRY,nestedOut.toByteArray());
    try(OutputStream raw=getContentResolver().openOutputStream(out);ZipOutputStream zout=new ZipOutputStream(new BufferedOutputStream(raw))){for(Map.Entry<String,byte[]> e:files.entrySet()){zout.putNextEntry(new ZipEntry(e.getKey()));zout.write(e.getValue());zout.closeEntry();}zout.finish();}
    setStatus("Yeni HWT kaydedildi: "+getName(out)+". Saatte yükleyip görünümü kontrol et.");toast("Yeni HWT kaydedildi.");
  }catch(Exception e){setStatus("Kaydetme hatası: "+e.getMessage());toast("Kaydedilemedi: "+e.getMessage());}}
  int sampleTextColor(Bitmap b){if(b==null)return Color.rgb(190,190,190);long r=0,g=0,bl=0,n=0;for(int y=0;y<b.getHeight();y++)for(int x=0;x<b.getWidth();x++){int c=b.getPixel(x,y);if(Color.alpha(c)>80){r+=Color.red(c);g+=Color.green(c);bl+=Color.blue(c);n++;}}if(n==0)return Color.rgb(190,190,190);return Color.rgb((int)(r/n),(int)(g/n),(int)(bl/n));}
  byte[] renderLabel(String text,int w,int h,int color)throws IOException{Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);p.setColor(color);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));float size=Math.min(19f,h*0.86f);p.setTextSize(size);while(p.measureText(text)>w-7&&size>7){size-=0.5f;p.setTextSize(size);}Paint.FontMetrics fm=p.getFontMetrics();float baseline=(h-(fm.ascent+fm.descent))/2f;c.drawText(text,3,baseline,p);ByteArrayOutputStream o=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,o);b.recycle();return o.toByteArray();}
  String getName(Uri u){String n="watchface.hwt";try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&x>=0)n=c.getString(x);}}catch(Exception ignored){}return n;}
  byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return b.toByteArray();}
  void setStatus(String s){status.setText(s);}void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
